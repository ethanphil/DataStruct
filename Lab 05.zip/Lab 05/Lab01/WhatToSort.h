
#include <iostream>
#include <string>
#include <cmath>
#include <iomanip>
#include <sstream>

class TheArray{
	public:
	TheArray();
	void PrintEM();
    void BubbleSort(int arr[]);
    void InsertionSort(int arr[]);
    void MergeSort(int arr[]);
    void QuickSort(int arr[]);
    void RadixSort(int arr[]);

    private:
    int small[10];
    int schmedium[100];
    int medium[500];
    int large[5000];
    int magnumxl[25000];
};