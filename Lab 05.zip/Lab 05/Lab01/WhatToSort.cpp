
#include "WhatToSort.h"
#include <chrono>
typedef std::chrono::high_resolution_clock Clock;


using namespace std;

TheArray::TheArray() {
    srand(time(NULL));
	for (int i = 0; i < 10; i++)
    {
       small[i] = rand()%20;
    }
    for (int i = 0; i < 100; i++)
    {
        schmedium[i] = rand()%200;
    }
    for (int i = 0; i < 500; i++)
    {
        medium[i] = rand()%1000;
    }
    for (int i = 0; i < 5000; i++)
    {
        large[i] = rand()%10000;
    }
    for (int i = 0; i < 25000; i++)
    {
        magnumxl[i] = rand()%50000;
    }
}

void TheArray::BubbleSort(int arr[])
{
    auto t1 = Clock.now();
    int i, j,temp;
    for(i = 0; i<sizeof(arr); i++) {
        for(j = i+1; j<5; j++) {
            if(arr[j] < arr[i]) {
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
    auto t2 = Clock.now();
}

void TheArray::InsertionSort(int arr[])
{
    
}

void TheArray::MergeSort(int arr[])
{
    
}

void TheArray::QuickSort(int arr[])
{
    
}

void TheArray::RadixSort(int arr[])
{
    
}


