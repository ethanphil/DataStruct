// tests.cpp
#include "SomeThing.h"
#include <gtest/gtest.h>


		
 		TEST(Card,ValueTest)
		{

		}

 
int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
